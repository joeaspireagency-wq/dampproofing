# DryStone Damp Specialists: demonstration website

A single-page, frontend-only demo site for a fictional UK damp proofing company
(DryStone Damp Specialists, Bristol). Everything is fictional and no data leaves the browser.

The built site is one self-contained file: `docs/index.html` (HTML, CSS, JS, fonts and
photos all inlined, no external requests).

## Run it

Open `docs/index.html` in a browser. No server needed.

## Publish on GitHub Pages

1. Push this repo to GitHub.
2. Settings > Pages > Source: "Deploy from a branch", branch `main`, folder `/docs`.
3. The site goes live at `https://<your-username>.github.io/<repo-name>/`.

## Edit and rebuild

Requires Python 3 only (standard library).

```bash
python3 build.py        # writes docs/index.html
```

| Path | What it is |
| --- | --- |
| `src/shell.html` | Page head, meta tags and placeholders |
| `src/styles.css` | All styles |
| `src/js/01-data.js` | Business details (phone, nav), copy, FAQ, reviews, quote form validation, demo quote service |
| `src/js/02-art.js` | Icons and generated illustrations, dividers, ambient shapes |
| `src/js/03-render.js` | Section renderers (hero, symptoms, pricing, case study, etc.) |
| `src/js/04-behaviour.js` | Menu, quote popup, before/after slider, reviews slider, FAQ |
| `src/*.jpg` | Photos (hero background, owner, symptom cards, before/after) |
| `fonts/` | Manrope and Inter variable fonts (latin subset, inlined at build) |

## Notes

- The "Get Your Free Quote" popup uses a demo service that makes no network request.
  To go live, replace `demoQuoteService` in `src/js/01-data.js` with a real endpoint.
- Phone number and WhatsApp link live in `SITE_CONFIG` at the top of `src/js/01-data.js`.
- Reviews, prices, the case study and the owner details are placeholder content.
- Fonts are licensed under the SIL Open Font License (via Fontsource).
