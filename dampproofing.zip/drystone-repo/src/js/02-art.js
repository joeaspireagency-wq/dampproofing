/* =====================================================================
   03. ICONS (Lucide-style paths, inline so nothing is fetched)
   ===================================================================== */
const ICON_PATHS = {
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  shield: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  umbrella: '<path d="M22 12a10.06 10.06 1 0 0-20 0Z"/><path d="M12 12v8a2 2 0 0 0 4 0"/><path d="M12 2v1"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  droplet: '<path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>',
  rain: '<path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"/><path d="M16 14v6"/><path d="M8 14v6"/><path d="M12 16v6"/>',
  wind: '<path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/><path d="M9.6 4.6A2 2 0 1 1 11 8H2"/><path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>',
  waves: '<path d="M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/>',
  brick: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M12 9v6"/><path d="M16 15v6"/><path d="M16 3v6"/><path d="M3 15h18"/><path d="M3 9h18"/><path d="M8 15v6"/><path d="M8 3v6"/>',
  bug: '<path d="m8 2 1.88 1.88"/><path d="M14.12 3.88 16 2"/><path d="M9 7.13v-1a3.003 3.003 0 1 1 6 0v1"/><path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"/><path d="M12 20v-9"/><path d="M6.53 9C4.6 8.8 3 7.1 3 5"/><path d="M6 13H2"/><path d="M3 21c0-2.1 1.7-3.9 3.8-4"/><path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"/><path d="M22 13h-4"/><path d="M17.2 17c2.1.1 3.8 1.9 3.8 4"/>',
  wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  usercheck: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="m16 11 2 2 4-4"/>',
  pound: '<path d="M18 7c0-5.333-8-5.333-8 0"/><path d="M10 7v14"/><path d="M6 21h12"/><path d="M6 13h10"/>',
  sparkle: '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/>',
  menu: '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  left: '<path d="m15 18-6-6 6-6"/>',
  right: '<path d="m9 18 6-6-6-6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  arrow: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  pin: '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
  mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  alert: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/>',
  chat: '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
  arrows: '<path d="m18 8 4 4-4 4"/><path d="m6 8-4 4 4 4"/>'
};
function icon(name, size = 22, extra = "") {
  const fill = name === "star" ? ' fill="currentColor"' : ' fill="none"';
  return `<svg class="icon ${extra}" width="${size}" height="${size}" viewBox="0 0 24 24"${fill} stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICON_PATHS[name] || ""}</svg>`;
}
function stars(n = 5, size = 18) {
  return `<span class="stars" role="img" aria-label="${n} out of 5 stars">${Array.from({ length: n }, () => icon("star", size)).join("")}</span>`;
}

const LOGO_MARK = `<svg viewBox="0 0 40 40" aria-hidden="true" focusable="false"><rect x="1" y="1" width="38" height="38" rx="10" fill="#1E293B"/><path d="M6 31h28M6 24.5h28M13 31v-6.5M22 31v-6.5M30 24.5V18" stroke="#fff" stroke-opacity=".28" stroke-width="1.6" stroke-linecap="round"/><path d="M20 7.5c3.3 4.4 6.2 7.7 6.2 11.2a6.2 6.2 0 0 1-12.4 0c0-3.5 2.9-6.8 6.2-11.2Z" fill="#0D9488"/><path d="M17.6 19.4a2.5 2.5 0 0 0 2 2.4" stroke="#fff" stroke-width="1.6" stroke-linecap="round" fill="none" opacity=".85"/></svg>`;

/* =====================================================================
   04. IMAGE MANIFEST (swap `svg` for a real `src` photo later: edit this one place)
   ===================================================================== */
const IMAGES = {
  "symptom-mould": { alt: "", ratio: "4:3", usage: "Symptoms card" },
  "symptom-tide": { alt: "", ratio: "4:3", usage: "Symptoms card" },
  "symptom-peel": { alt: "", ratio: "4:3", usage: "Symptoms card" },
  "symptom-musty": { alt: "", ratio: "4:3", usage: "Symptoms card" },
  "case-before": { alt: "Living room wall before treatment: tide marks up to 1.1 metres, peeling paint and a moisture reading of 38 percent", ratio: "16:9", usage: "Case study before" },
  "case-after": { alt: "The same wall after treatment: fresh plaster, clean paint and a moisture reading of 11 percent", ratio: "16:9", usage: "Case study after" },
  "hero": { alt: "", ratio: "4:4.4", usage: "Hero visual" },
  "callum": { alt: "Illustrated placeholder portrait of Callum Reeves, damp surveyor, holding a clipboard", ratio: "1:1", usage: "Meet Callum" }
};

/* ---------- illustration helpers (seeded so every load looks identical) ---------- */
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
let _uid = 0;
const uid = p => p + (++_uid);

function wallDefs(id, tone) {
  const [a, b] = tone;
  return `<defs>
    <linearGradient id="${id}w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>
    <filter id="${id}n" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="4" result="t"/><feColorMatrix type="matrix" values="0 0 0 0 .2  0 0 0 0 .18  0 0 0 0 .14  0 0 0 .1 0"/></filter>
    <radialGradient id="${id}m"><stop offset="0" stop-color="#1b2420" stop-opacity=".55"/><stop offset="1" stop-color="#1b2420" stop-opacity="0"/></radialGradient>
    <linearGradient id="${id}t" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b08a58" stop-opacity=".0"/><stop offset=".25" stop-color="#b08a58" stop-opacity=".38"/><stop offset="1" stop-color="#8d6b3f" stop-opacity=".62"/></linearGradient>
  </defs>`;
}
function baseRoom(id, W, H, tone, skirtY, opts = {}) {
  const skirtH = Math.round(H * .115), floorY = skirtY + skirtH;
  return `${wallDefs(id, tone)}
    <rect width="${W}" height="${H}" fill="url(#${id}w)"/>
    <rect width="${W}" height="${H}" filter="url(#${id}n)"/>
    ${opts.ceiling ? `<rect width="${W}" height="${Math.round(H * .045)}" fill="#F7F5F0"/><rect y="${Math.round(H * .045)}" width="${W}" height="2" fill="#000" opacity=".08"/>` : ""}
    <rect y="${skirtY}" width="${W}" height="${skirtH}" fill="${opts.skirt || "#F3F1EC"}"/>
    <rect y="${skirtY}" width="${W}" height="2" fill="#fff" opacity=".8"/>
    <rect y="${skirtY + 2}" width="${W}" height="3" fill="#000" opacity=".07"/>
    <rect y="${floorY}" width="${W}" height="${H - floorY}" fill="#8F7A60"/>
    ${[0, 1, 2, 3, 4, 5].map(i => `<rect x="${i * W / 5 + 6}" y="${floorY}" width="2" height="${H - floorY}" fill="#000" opacity=".16"/>`).join("")}
    <rect y="${floorY}" width="${W}" height="4" fill="#000" opacity=".18"/>`;
}

function sceneMould() {
  const id = uid("mo"), r = rng(11); let blots = "", patches = "";
  patches += `<ellipse cx="62" cy="38" rx="120" ry="70" fill="url(#${id}m)" opacity=".7"/>`;
  patches += `<ellipse cx="300" cy="22" rx="70" ry="30" fill="url(#${id}m)" opacity=".45"/>`;
  for (let i = 0; i < 90; i++) {
    const t = Math.pow(r(), 2.1), x = 8 + t * 170, y = 16 + Math.pow(r(), 1.7) * 120, s = .8 + r() * 3.2;
    const dark = r() > .45 ? "#1d2723" : "#34443a";
    blots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${s.toFixed(1)}" fill="${dark}" opacity="${(.35 + r() * .55).toFixed(2)}"/>`;
  }
  for (let i = 0; i < 28; i++) {
    const x = 230 + r() * 150, y = 16 + r() * 36, s = .8 + r() * 2;
    blots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${s.toFixed(1)}" fill="#1d2723" opacity="${(.3 + r() * .4).toFixed(2)}"/>`;
  }
  let drops = "";
  for (let i = 0; i < 30; i++) {
    const x = 262 + r() * 112, y = 78 + r() * 92;
    drops += `<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="${(1.1 + r()).toFixed(1)}" ry="${(1.8 + r() * 1.6).toFixed(1)}" fill="#fff" opacity="${(.45 + r() * .4).toFixed(2)}"/>`;
  }
  let sill = "";
  for (let i = 0; i < 12; i++) sill += `<circle cx="${(256 + r() * 126).toFixed(1)}" cy="${(190 + r() * 6).toFixed(1)}" r="${(.8 + r() * 2).toFixed(1)}" fill="#1d2723" opacity=".6"/>`;
  return `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" role="img" aria-label="__ALT__" xmlns="http://www.w3.org/2000/svg">
    ${baseRoom(id, 400, 300, ["#E7E3DA", "#DAD4C7"], 236, { ceiling: true })}
    ${patches}${blots}
    <rect x="252" y="62" width="136" height="132" rx="4" fill="#F7F5F0"/>
    <rect x="260" y="70" width="120" height="116" fill="#C9D6DE"/><rect x="260" y="70" width="120" height="116" fill="#fff" opacity=".18"/>
    <path d="M320 70v116M260 128h120" stroke="#F7F5F0" stroke-width="5"/>${drops}
    <rect x="246" y="192" width="148" height="12" rx="3" fill="#F1EEE8"/><rect x="246" y="202" width="148" height="3" fill="#000" opacity=".08"/>${sill}
  </svg>`;
}
function sceneTide() {
  const id = uid("ti"), r = rng(23); let salt = "";
  const wave = (x0, y0, w, amp) => { let d = `M${x0} ${y0}`; const n = 16; for (let i = 1; i <= n; i++) d += ` L${(x0 + w * i / n).toFixed(1)} ${(y0 + (r() - .5) * amp).toFixed(1)}`; return d; };
  const top = wave(0, 128, 400, 9);
  for (let i = 0; i < 70; i++) salt += `<circle cx="${(r() * 400).toFixed(1)}" cy="${(112 + r() * 30).toFixed(1)}" r="${(.6 + r() * 1.6).toFixed(1)}" fill="#fff" opacity="${(.5 + r() * .45).toFixed(2)}"/>`;
  return `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" role="img" aria-label="__ALT__" xmlns="http://www.w3.org/2000/svg">
    ${baseRoom(id, 400, 300, ["#E9E5DD", "#DCD6CA"], 236)}
    <path d="${top} L400 236 L0 236 Z" fill="url(#${id}t)"/>
    <path d="${top}" fill="none" stroke="#9c7a49" stroke-width="2.4" opacity=".55"/>
    <path d="${wave(0, 120, 400, 7)}" fill="none" stroke="#fff" stroke-width="3" opacity=".55"/>
    ${salt}
    <rect y="231" width="400" height="5" fill="#8d6b3f" opacity=".35"/>
    <g opacity=".55" stroke="#8d6b3f" stroke-width="1"><path d="M44 236v-70M120 236v-48M210 236v-85M300 236v-58M360 236v-76" stroke-dasharray="2 5"/></g>
  </svg>`;
}
function scenePeel() {
  const id = uid("pe"), r = rng(5); let patches = "";
  const flake = (cx, cy, s, rot) => {
    const pts = []; const n = 9;
    for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2, rr = s * (.62 + r() * .5); pts.push([cx + Math.cos(a) * rr * 1.25, cy + Math.sin(a) * rr]); }
    const d = "M" + pts.map(p => p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" L") + " Z";
    return `<g transform="rotate(${rot} ${cx} ${cy})"><path d="${d}" fill="#B6AB99"/><path d="${d}" fill="#8f8372" opacity=".35" transform="translate(2 3)"/>` +
      `<path d="M${(cx - s * .9).toFixed(1)} ${(cy + s * .35).toFixed(1)} q${(s * .8).toFixed(1)} ${(-s * .8).toFixed(1)} ${(s * 1.7).toFixed(1)} ${(-s * .1).toFixed(1)} l-2 7 q${(-s * .9).toFixed(1)} ${(-s * .5).toFixed(1)} ${(-s * 1.55).toFixed(1)} ${(s * .1).toFixed(1)}Z" fill="#E4EAEC" stroke="#9aa6ab" stroke-width=".8"/></g>`;
  };
  [[70, 190, 38, -8], [150, 205, 26, 12], [255, 170, 44, 4], [330, 205, 28, -14], [200, 120, 22, 20], [110, 110, 16, -20], [340, 120, 20, 8], [40, 85, 14, 0]].forEach(([x, y, s, rot]) => patches += flake(x, y, s, rot));
  let curls = "";
  for (let i = 0; i < 18; i++) curls += `<path d="M${(r() * 380 + 10).toFixed(1)} ${(60 + r() * 150).toFixed(1)} q5 -4 10 1 q-3 6 -10 -1" fill="#E4EAEC" stroke="#9aa6ab" stroke-width=".7" opacity=".9"/>`;
  return `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" role="img" aria-label="__ALT__" xmlns="http://www.w3.org/2000/svg">
    ${baseRoom(id, 400, 300, ["#D4DEE2", "#C6D2D7"], 236, { skirt: "#EDEAE3" })}
    ${patches}${curls}
  </svg>`;
}
function sceneMusty() {
  const id = uid("mu"), r = rng(31); let mottle = "", vapour = "";
  for (let i = 0; i < 46; i++) mottle += `<circle cx="${(r() * 400).toFixed(1)}" cy="${(190 + r() * 44).toFixed(1)}" r="${(2 + r() * 8).toFixed(1)}" fill="#6d6f58" opacity="${(.05 + r() * .12).toFixed(2)}"/>`;
  [[250, 80], [285, 96], [320, 74], [352, 100]].forEach(([x, y], i) => vapour += `<path d="M${x} ${y + 110} c-16 -26 16 -46 0 -72 s16 -40 0 -62" fill="none" stroke="#7b7d68" stroke-width="2.2" stroke-linecap="round" stroke-dasharray="1 7" opacity="${.5 - i * .06}"/>`);
  return `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" role="img" aria-label="__ALT__" xmlns="http://www.w3.org/2000/svg">
    ${baseRoom(id, 400, 300, ["#DCD8CC", "#CCC7B8"], 236)}
    <ellipse cx="200" cy="150" rx="260" ry="160" fill="#000" opacity=".06"/>
    ${mottle}
    <rect x="40" y="40" width="150" height="198" rx="4" fill="#8B6B4A"/><rect x="48" y="48" width="134" height="182" rx="2" fill="#A2805B"/>
    <path d="M115 48v182" stroke="#6f5338" stroke-width="3"/>
    <path d="M115 48 L184 40 L184 238 L115 230Z" fill="#2c2418" opacity=".78"/>
    <path d="M115 48 L184 40 L184 238 L115 230Z" fill="none" stroke="#6f5338" stroke-width="3"/>
    <circle cx="104" cy="140" r="4" fill="#d6c4a2"/>
    <path d="M150 90h18M150 118h18M150 150h18" stroke="#554733" stroke-width="3" opacity=".6" stroke-linecap="round"/>
    ${vapour}
  </svg>`;
}

/* Large 16:9 living-room scene with identical geometry before and after treatment */
function sceneRoom(state) {
  const id = uid("rm"), r = rng(state === "before" ? 77 : 78), W = 800, H = 450, skirtY = 352;
  const before = state === "before";
  const tone = before ? ["#E4DFD3", "#D6CFBF"] : ["#F4F1EA", "#ECE8DF"];
  let stain = "", speck = "", peel = "", mould = "";
  if (before) {
    const top = (() => { let d = "M0 168"; for (let i = 1; i <= 40; i++) d += ` L${i * 20} ${(168 + (r() - .5) * 14).toFixed(1)}`; return d; })();
    stain = `<path d="${top} L800 ${skirtY} L0 ${skirtY} Z" fill="url(#${id}t)"/><path d="${top}" fill="none" stroke="#9c7a49" stroke-width="3" opacity=".5"/>`;
    for (let i = 0; i < 130; i++) speck += `<circle cx="${(r() * 800).toFixed(1)}" cy="${(150 + r() * 40).toFixed(1)}" r="${(.7 + r() * 2).toFixed(1)}" fill="#fff" opacity="${(.45 + r() * .45).toFixed(2)}"/>`;
    [[300, 300, 30], [610, 270, 24], [470, 220, 20], [90, 320, 22], [720, 205, 16]].forEach(([x, y, s]) => {
      peel += `<path d="M${x - s} ${y} q${s * .4} ${-s} ${s} ${-s * .3} q${s * .8} ${s * .4} ${s * .2} ${s * .9} q${-s * .5} ${s * .6} ${-s * 1.2} ${s * .1}Z" fill="#B6AB99"/><path d="M${x - s} ${y} q${s * .6} ${-s * .9} ${s * 1.2} ${-s * .2} l-3 8 q${-s * .6} ${-s * .4} ${-s * 1.1} ${s * .1}Z" fill="#E6E1D6" stroke="#9a917f" stroke-width=".9"/>`;
    });
    for (let i = 0; i < 26; i++) mould += `<circle cx="${(30 + r() * 120).toFixed(1)}" cy="${(380 - r() * 18).toFixed(1)}" r="${(1 + r() * 2.4).toFixed(1)}" fill="#1d2723" opacity=".5"/>`;
  }
  const meter = (txt, hot) => `<g transform="translate(398 238)">
      <rect x="-6" y="64" width="64" height="8" rx="3" fill="#0F172A" opacity=".18" transform="translate(0 10)"/>
      <path d="M12 0v-20M36 0v-20" stroke="#64748B" stroke-width="3" stroke-linecap="round" transform="translate(0 4)"/>
      <rect x="-8" y="4" width="64" height="96" rx="12" fill="#1E293B"/><rect x="-2" y="12" width="52" height="40" rx="6" fill="${hot ? "#FDE7B0" : "#D7F0EA"}"/>
      <text x="24" y="40" text-anchor="middle" font-family="Inter,Arial,sans-serif" font-weight="800" font-size="22" fill="#0F172A">${txt}</text>
      <rect x="4" y="62" width="40" height="6" rx="3" fill="#334155"/><rect x="4" y="62" width="${hot ? 34 : 12}" height="6" rx="3" fill="${hot ? "#F59E0B" : "#0D9488"}"/>
      <circle cx="24" cy="84" r="6" fill="#334155"/></g>`;
  return `<svg viewBox="0 0 800 450" preserveAspectRatio="xMidYMid slice" role="img" aria-label="__ALT__" xmlns="http://www.w3.org/2000/svg">
    ${baseRoom(id, 800, 450, tone, skirtY, { skirt: before ? "#EFECE5" : "#FBFAF7" })}
    ${stain}${speck}${peel}${mould}
    <g><rect x="78" y="70" width="190" height="205" rx="5" fill="#F7F5F0"/><rect x="90" y="82" width="166" height="181" fill="#C7D6DF"/><rect x="90" y="82" width="166" height="181" fill="#fff" opacity=".22"/><path d="M173 82v181M90 172h166" stroke="#F7F5F0" stroke-width="7"/><rect x="68" y="275" width="210" height="14" rx="3" fill="#F3F0EA"/><rect x="68" y="287" width="210" height="4" fill="#000" opacity=".08"/></g>
    <g><rect x="540" y="196" width="170" height="130" rx="6" fill="#FBFBFA" stroke="#D5D9DD" stroke-width="2"/>${[0, 1, 2, 3, 4, 5, 6].map(i => `<rect x="${552 + i * 22}" y="206" width="14" height="110" rx="5" fill="#EEF1F3" stroke="#D5D9DD"/>`).join("")}</g>
    <rect x="742" y="248" width="26" height="40" rx="4" fill="#F7F5F0" stroke="#D5D9DD" stroke-width="2"/><circle cx="755" cy="262" r="3" fill="#B8BEC4"/><circle cx="755" cy="276" r="3" fill="#B8BEC4"/>
    ${meter(before ? "38%" : "11%", before)}
  </svg>`;
}

function sceneCallum() {
  const id = uid("ca");
  return `<svg viewBox="0 0 400 400" preserveAspectRatio="xMidYMid slice" role="img" aria-label="__ALT__" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#334155"/><stop offset="1" stop-color="#1E293B"/></linearGradient>
    <pattern id="${id}p" width="60" height="30" patternUnits="userSpaceOnUse"><path d="M0 .5h60M0 15.5h60M30 .5v15M0 15.5v14.5M60 15.5v14.5" stroke="#fff" stroke-opacity=".07" fill="none"/></pattern></defs>
    <rect width="400" height="400" fill="url(#${id}b)"/><rect width="400" height="400" fill="url(#${id}p)"/>
    <path d="M40 400c4-78 52-112 160-112s156 34 160 112Z" fill="#0F172A"/>
    <path d="M40 400c4-78 52-112 160-112s156 34 160 112Z" fill="#475569" opacity=".35"/>
    <path d="M150 292l50 46 50-46 22 12-72 70-72-70Z" fill="#E2E8F0"/>
    <rect x="178" y="236" width="44" height="62" rx="18" fill="#D7A98A"/>
    <ellipse cx="200" cy="190" rx="60" ry="70" fill="#E3B696"/>
    <path d="M140 182c-4-64 28-84 62-84 38 0 64 24 58 84-8-30-26-44-60-44s-52 14-60 44Z" fill="#3B2F2A"/>
    <path d="M142 214c6 46 30 62 58 62s52-16 58-62c-12 24-30 36-58 36s-46-12-58-36Z" fill="#5a463b" opacity=".5"/>
    <ellipse cx="140" cy="198" rx="8" ry="14" fill="#D7A98A"/><ellipse cx="260" cy="198" rx="8" ry="14" fill="#D7A98A"/>
    <circle cx="176" cy="188" r="4.2" fill="#2a1f1a"/><circle cx="224" cy="188" r="4.2" fill="#2a1f1a"/>
    <path d="M166 174q10-7 20-1M214 173q10-6 20 1" stroke="#3B2F2A" stroke-width="4" stroke-linecap="round" fill="none"/>
    <path d="M182 232q18 12 36 0" stroke="#7a4a3a" stroke-width="4" stroke-linecap="round" fill="none"/>
    <g transform="rotate(-8 300 330)"><rect x="262" y="270" width="92" height="120" rx="8" fill="#0D9488"/><rect x="270" y="284" width="76" height="98" rx="4" fill="#F8FAFC"/><rect x="292" y="262" width="32" height="16" rx="5" fill="#475569"/><path d="M280 304h56M280 320h56M280 336h40M280 352h48" stroke="#94A3B8" stroke-width="4" stroke-linecap="round"/></g>
  </svg>`;
}

function imageSvg(id) {
  const alt = IMAGES[id].alt;
  const map = { "symptom-mould": sceneMould, "symptom-tide": sceneTide, "symptom-peel": scenePeel, "symptom-musty": sceneMusty, "case-before": () => sceneRoom("before"), "case-after": () => sceneRoom("after"), "hero": () => sceneRoom("before"), "callum": sceneCallum };
  const svg = map[id]();
  return svg.replace("role=\"img\" aria-label=\"__ALT__\"", alt ? `role="img" aria-label="${alt}"` : 'aria-hidden="true"');
}

const TERRACE = (() => {
  let h = "";
  for (let i = 0; i < 7; i++) {
    const x = 20 + i * 110, y = 70 + (i % 2) * 6;
    h += `<path d="M${x} 300V${y + 40}L${x + 50} ${y}L${x + 100} ${y + 40}V300" /><path d="M${x + 38} ${y + 40 - 30}v-34h14v22"/>`;
    h += `<rect x="${x + 16}" y="${y + 70}" width="26" height="38"/><rect x="${x + 58}" y="${y + 70}" width="26" height="38"/><rect x="${x + 16}" y="${y + 150}" width="26" height="38"/><rect x="${x + 58}" y="${y + 180}" width="26" height="60"/>`;
  }
  return `<svg viewBox="0 0 800 300" fill="none" stroke="#fff" stroke-opacity=".28" stroke-width="1.5" aria-hidden="true" focusable="false" preserveAspectRatio="xMinYMax meet">${h}</svg>`;
})();

/* =====================================================================
   05. AMBIENT SHAPES (timer-driven, transform + opacity only)
   [type, x%, y%, size, dx, dy, rot, dur, delay, colour, opacity, baseAngle]
   ===================================================================== */
const SHAPE_SETS = {
  hero: [
    ["c", 80, -14, 340, -40, 36, 0, 32, -9, "teal", .12], ["c", -9, 58, 230, 45, -30, 0, 28, -14, "teal", .09],
    ["r", 66, 52, 190, 30, -40, 0, 36, -20, "white", .08], ["r", 70, 57, 120, -24, 30, 0, 30, -5, "white", .07],
    ["l", 4, 14, 280, 40, 30, 8, 26, -11, "white", .08, -35], ["l", 90, 80, 240, -50, -30, -10, 38, -23, "white", .07, 28],
    ["d", 42, 88, 170, 36, -20, 6, 22, -7, "white", .09, -20], ["c", 54, -6, 96, 30, 50, 0, 20, -3, "teal", .14]
  ],
  guarantee: [
    ["c", 84, -10, 300, -36, 40, 0, 34, -12, "teal", .1], ["r", 4, 70, 170, 30, -36, 0, 30, -8, "white", .07],
    ["r", 8, 75, 100, -20, 30, 0, 26, -3, "white", .06], ["l", 88, 70, 260, -40, -30, 8, 36, -20, "white", .07, 30],
    ["c", -6, 6, 160, 40, 30, 0, 24, -15, "teal", .08], ["d", 55, 94, 150, 30, -14, 5, 24, -9, "white", .08, -12]
  ],
  callum: [
    ["c", 90, -12, 280, -34, 36, 0, 34, -10, "teal", .06], ["r", 2, 74, 180, 28, -34, 0, 30, -7, "navy", .05],
    ["l", 80, 86, 240, -40, -24, 8, 36, -18, "navy", .04, 26], ["c", -6, 0, 150, 38, 30, 0, 26, -12, "navy", .035],
    ["d", 46, 96, 140, 26, -14, 5, 24, -6, "navy", .05, -14]
  ],
  case: [["c", 92, -8, 240, -30, 30, 0, 34, -10, "teal", .06], ["r", -3, 70, 160, 26, -30, 0, 30, -6, "navy", .04], ["l", 78, 90, 220, -34, -20, 8, 38, -15, "navy", .04, 24]],
  final: [
    ["c", 86, -14, 320, -38, 40, 0, 32, -9, "teal", .12], ["c", -8, 60, 220, 44, -30, 0, 28, -14, "teal", .09],
    ["r", 6, 12, 180, 30, 36, 0, 34, -20, "white", .07], ["r", 10, 17, 110, -22, 28, 0, 28, -5, "white", .06],
    ["l", 82, 76, 260, -48, -30, -9, 38, -23, "white", .07, 28], ["d", 38, 92, 160, 34, -18, 6, 22, -7, "white", .08, -16]
  ]
};
function shapesHtml(key, theme) {
  const col = { teal: "13,148,136", white: "255,255,255", navy: "30,41,59" };
  const cls = { c: "s-c", r: "s-r", l: "s-l", d: "s-d" };
  return `<div class="shapes" aria-hidden="true" data-shapes>` + SHAPE_SETS[key].map(s => {
    const [t, x, y, size, dx, dy, rot, dur, delay, c, o, ang] = s;
    return `<span class="shape ${cls[t]}" style="--x:${x};--y:${y};--size:${size};--dx:${dx};--dy:${dy};--rot:${rot};--dur:${dur}s;--delay:${delay}s;--ang:${ang || 0};--col:rgba(${col[c]},${o})"></span>`;
  }).join("") + `</div>`;
}

/* =====================================================================
   06. SECTION DIVIDERS (A droplet line, B slow wave, C dotted pulse)
   ===================================================================== */
const BG = { navy: "#1E293B", white: "#FFFFFF", off: "#F8FAFC", deep: "#17212F" };
function dividerHtml(variant, from, to) {
  const style = `style="--from:${BG[from]};--to:${BG[to]}"`;
  if (variant === "A") {
    return `<div class="divider div-a" ${style} aria-hidden="true" data-divider="A"><div class="row">
      <svg class="ln l" viewBox="0 0 100 2" preserveAspectRatio="none" focusable="false"><line x1="100" y1="1" x2="0" y2="1" pathLength="1"/></svg>
      ${icon("droplet", 22, "drop")}
      <svg class="ln r" viewBox="0 0 100 2" preserveAspectRatio="none" focusable="false"><line x1="0" y1="1" x2="100" y2="1" pathLength="1"/></svg></div></div>`;
  }
  if (variant === "B") {
    return `<div class="divider div-b" ${style} aria-hidden="true" data-divider="B"><svg viewBox="0 0 2400 80" preserveAspectRatio="none" focusable="false"><path d="M0 40C200 0 400 0 600 40S1000 80 1200 40S1600 0 1800 40S2200 80 2400 40V80H0Z"/></svg></div>`;
  }
  const dots = Array.from({ length: 48 }, (_, i) => `<i style="--d:${(i * 55)}ms"></i>`).join("");
  return `<div class="divider div-c" ${style} aria-hidden="true" data-divider="C"><div class="dots-row">${dots}</div></div>`;
}
