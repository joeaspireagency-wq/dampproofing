/* =====================================================================
   08. BEHAVIOUR
   ===================================================================== */
// Snapshot of the empty page skeleton, used to build the "Mobile" preview iframe (see initPreview).
const PAGE_SOURCE = "<!DOCTYPE html>\n" + document.documentElement.outerHTML;
const IN_PHONE_FRAME = window.name === "ds-phone";

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const reducedMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;
let menuOpen = false;

/* ---------- navigation (in-page anchors only; every CTA opens the quote popup instead) ---------- */
function scrollToEl(el) {
  const behavior = reducedMotion() ? "auto" : "smooth";
  if (el === document.body) window.scrollTo({ top: 0, behavior });
  else el.scrollIntoView({ behavior, block: "start" });
}
function initNav(menu) {
  document.addEventListener("click", e => {
    const a = e.target.closest && e.target.closest('a[href^="#"]');
    if (!a) return;
    const href = a.getAttribute("href");
    e.preventDefault();
    if (href === "#") return;                       // placeholder links (privacy, cookies, terms)
    menu.close(false);
    const target = href === "#top" ? document.body : $(href);
    if (!target) return;
    scrollToEl(target);
    if (href === "#main") { target.setAttribute("tabindex", "-1"); target.focus({ preventScroll: true }); }
  });
  const header = $("#site-header");
  let ticking = false;
  window.addEventListener("scroll", () => {
    if (ticking) return; ticking = true;
    requestAnimationFrame(() => { header.classList.toggle("is-scrolled", window.scrollY > 8); ticking = false; });
  }, { passive: true });
}

/* ---------- CTA cursor glow (one handler for every CTA button) ---------- */
function initCtaGlow() {
  if (!window.matchMedia("(hover: hover)").matches) return;
  let raf = 0, last = null;
  const apply = () => {
    raf = 0; if (!last || reducedMotion()) return;
    const r = last.el.getBoundingClientRect();
    last.el.style.setProperty("--mx", (last.x - r.left) + "px");
    last.el.style.setProperty("--my", (last.y - r.top) + "px");
  };
  const onMove = e => {
    const el = e.target.closest && e.target.closest(".cta");
    if (!el) return;
    last = { el, x: e.clientX, y: e.clientY };
    if (!raf) raf = requestAnimationFrame(apply);
  };
  document.addEventListener("pointerover", onMove, { passive: true });
  document.addEventListener("pointermove", onMove, { passive: true });
}

/* ---------- mobile menu (focus trap, Escape, aria-expanded) ---------- */
function initMenu() {
  const btn = $("#menu-btn"), panel = $("#mobile-menu");
  const focusables = () => [btn, ...$$("a[href], button", panel)];
  function set(open, restoreFocus = true) {
    if (open === menuOpen) return;
    menuOpen = open;
    panel.classList.toggle("is-open", open);
    btn.setAttribute("aria-expanded", String(open));
    btn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    btn.innerHTML = icon(open ? "x" : "menu", 24);
    document.documentElement.style.overflow = open ? "hidden" : "";
    if (open) { const first = $("a", panel); first && first.focus(); }
    else if (restoreFocus) btn.focus();
    }
  btn.addEventListener("click", () => set(!menuOpen));
  document.addEventListener("keydown", e => {
    if (!menuOpen) return;
    if (e.key === "Escape") { e.preventDefault(); set(false, true); return; }
    if (e.key === "Tab") {
      const f = focusables(), first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  window.matchMedia("(min-width: 1024px)").addEventListener("change", ev => { if (ev.matches) set(false, false); });
  return { close: restore => set(false, restore) };
}

/* ---------- FAQ accordion (one open at a time, first open by default) ---------- */
function initFaq() {
  const root = $("[data-faq]");
  const btns = $$("[data-faq-btn]", root);
  function toggle(btn) {
    const willOpen = btn.getAttribute("aria-expanded") !== "true";
    btns.forEach(b => {
      const open = b === btn && willOpen, panel = document.getElementById(b.getAttribute("aria-controls"));
      b.setAttribute("aria-expanded", String(open));
      panel.classList.toggle("is-open", open);
      if (open) panel.removeAttribute("inert"); else panel.setAttribute("inert", "");
    });
  }
  btns.forEach(b => b.addEventListener("click", () => toggle(b)));
}

/* ---------- testimonial slider: arrows, dots, swipe, keyboard, no autoplay ---------- */
function initSlider() {
  const root = $("[data-slider]"), vp = $("[data-viewport]", root), track = $("[data-track]", root);
  const slides = $$("[data-slide]", root), prev = $("[data-prev]", root), next = $("[data-next]", root);
  const dotsEl = $("[data-dots]", root), count = $("[data-count]", root), total = slides.length;
  const mqL = window.matchMedia("(min-width: 1024px)"), mqM = window.matchMedia("(min-width: 768px)");
  let idx = 0, pv = 1;
  const maxIdx = () => total - pv;
  function buildDots() {
    dotsEl.innerHTML = Array.from({ length: maxIdx() + 1 }, (_, i) => `<button type="button" data-dot="${i}" aria-label="Go to review ${i + 1}"><span></span></button>`).join("");
    $$("[data-dot]", dotsEl).forEach(d => d.addEventListener("click", () => go(+d.dataset.dot, true)));
  }
  function update() {
    const w = slides[0].offsetWidth;
    track.style.transform = `translateX(${-idx * (w + 24)}px)`;
    slides.forEach((s, i) => s.setAttribute("aria-hidden", i >= idx && i < idx + pv ? "false" : "true"));
    prev.disabled = idx === 0; next.disabled = idx >= maxIdx();
    $$("[data-dot]", dotsEl).forEach((d, i) => { if (i === idx) d.setAttribute("aria-current", "true"); else d.removeAttribute("aria-current"); });
    count.textContent = pv === 1 ? `Review ${idx + 1} of ${total}` : `Reviews ${idx + 1} to ${idx + pv} of ${total}`;
  }
  function go(i) { idx = Math.max(0, Math.min(maxIdx(), i)); update(); }
  function layout() { pv = mqL.matches ? 3 : mqM.matches ? 2 : 1; track.style.setProperty("--pv", pv); idx = Math.min(idx, maxIdx()); buildDots(); update(); }
  prev.addEventListener("click", () => go(idx - 1));
  next.addEventListener("click", () => go(idx + 1));
  vp.addEventListener("keydown", e => {
    if (e.key === "ArrowLeft") { e.preventDefault(); go(idx - 1); }
    else if (e.key === "ArrowRight") { e.preventDefault(); go(idx + 1); }
  });
  let sx = null;
  vp.addEventListener("pointerdown", e => { if (e.pointerType === "mouse" && e.button !== 0) return; sx = e.clientX; });
  vp.addEventListener("pointerup", e => { if (sx === null) return; const dx = e.clientX - sx; sx = null; if (Math.abs(dx) > 50) go(idx + (dx < 0 ? 1 : -1)); });
  vp.addEventListener("pointercancel", () => { sx = null; });
  mqL.addEventListener("change", layout); mqM.addEventListener("change", layout);
  window.addEventListener("resize", update);
  layout();
}

/* ---------- before / after comparison slider (role="slider") ---------- */
function initBeforeAfter() {
  const box = $("[data-ba]"), before = $("[data-ba-before]"), handle = $("[data-ba-handle]");
  let p = 50, dragging = false;
  function set(v) {
    p = Math.max(0, Math.min(100, v));
    const n = Math.round(p);
    before.style.clipPath = `inset(0 ${100 - p}% 0 0)`;
    handle.style.left = p + "%";
    handle.setAttribute("aria-valuenow", String(n));
    handle.setAttribute("aria-valuetext", `Showing ${n} percent before, ${100 - n} percent after`);
  }
  const fromEvent = e => { const r = box.getBoundingClientRect(); set((e.clientX - r.left) / r.width * 100); };
  box.addEventListener("pointerdown", e => { if (e.pointerType === "mouse" && e.button !== 0) return; dragging = true; box.setPointerCapture(e.pointerId); fromEvent(e); if (e.target.closest("[data-ba-handle]")) handle.focus({ preventScroll: true }); });
  box.addEventListener("pointermove", e => { if (dragging) fromEvent(e); });
  const end = e => { dragging = false; try { box.releasePointerCapture(e.pointerId); } catch (_) { /* not captured */ } };
  box.addEventListener("pointerup", end); box.addEventListener("pointercancel", end);
  handle.addEventListener("keydown", e => {
    const step = e.shiftKey ? 10 : 5;
    const map = { ArrowLeft: p - step, ArrowDown: p - step, ArrowRight: p + step, ArrowUp: p + step, PageDown: p - 10, PageUp: p + 10, Home: 0, End: 100 };
    if (e.key in map) { e.preventDefault(); set(map[e.key]); }
  });
  set(50);
}

/* ---------- decorative motion: pause off-screen, play dividers once ---------- */
function initMotion() {
  const io = new IntersectionObserver(entries => {
    entries.forEach(en => {
      const el = en.target;
      if (el.matches("[data-shapes]")) { el.classList.toggle("is-paused", !en.isIntersecting); return; }
      const v = el.dataset.divider;
      if (v === "B") el.classList.toggle("is-paused", !en.isIntersecting);
      else if (en.isIntersecting) { el.classList.add("in"); io.unobserve(el); }
    });
  }, { threshold: 0.01 });
  const ioDiv = new IntersectionObserver(entries => {
    entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add("in"); ioDiv.unobserve(en.target); } });
  }, { threshold: 0.3 });
  $$("[data-shapes]").forEach(el => { el.classList.add("is-paused"); io.observe(el); });
  $$("[data-divider]").forEach(el => {
    if (el.dataset.divider === "B") { el.classList.add("is-paused"); io.observe(el); }
    else if (reducedMotion()) el.classList.add("in");
    else ioDiv.observe(el);
  });
}

/* ---------- quote popup: multi-step, one tap moves to the next step ---------- */
function initQuoteModal() {
  const modal = $("#quote-modal"), dialog = $(".modal-dialog", modal);
  const backBtn = $("[data-qm-back]", modal), stepText = $("[data-qm-steptext]", modal), bars = $$(".qm-bar i", modal);
  const doneEl = $("[data-done]", modal), progress = $(".qm-progress", modal);
  const fields = { name: $("#q-name"), mobile: $("#q-mobile"), postcode: $("#q-postcode") };
  const data = { problem: "", postcode: "", name: "", mobile: "" };
  let step = 1, opener = null, busy = false, finished = false, advanceTimer = 0;

  const errFor = f => $("#q-" + f + "-err");
  function showErrors(errors, names) {
    names.forEach(f => {
      const el = fields[f], err = errFor(f);
      if (errors[f]) { err.innerHTML = icon("alert", 16) + "<span>" + esc(errors[f]) + "</span>"; el.setAttribute("aria-invalid", "true"); }
      else { err.textContent = ""; el.removeAttribute("aria-invalid"); }
    });
  }
  /** Validate only some fields with the one shared schema. */
  function check(names) {
    const parsed = QuoteSchema.safeParse(data);
    const errors = parsed.success ? {} : parsed.errors;
    const mine = {}; names.forEach(n => { if (errors[n]) mine[n] = errors[n]; });
    showErrors(mine, names.filter(n => n in fields));
    return mine;
  }
  Object.keys(fields).forEach(f => {
    const clear = () => { if (fields[f].getAttribute("aria-invalid")) showErrors({}, [f]); };
    fields[f].addEventListener("input", clear);
  });

  function show(n, focus = true) {
    step = n;
    $$("[data-step]", modal).forEach(sec => { sec.hidden = sec.dataset.step !== String(n); });
    const isDone = n === "done";
    bars.forEach((b, i) => b.classList.toggle("on", isDone || i < n));
    stepText.textContent = isDone ? "All done" : `Step ${n} of 3`;
    backBtn.hidden = isDone || n === 1;
    $(".qm-body", modal).scrollTop = 0;
    if (!focus) return;
    const sec = $(`[data-step="${n}"]`, modal);
    const target = n === 2 ? fields.postcode : n === 3 ? fields.name : $("h2", sec);
    target && target.focus({ preventScroll: true });
  }
  function syncSelected() { $$("[data-problem]", modal).forEach(b => b.setAttribute("aria-pressed", String(b.dataset.problem === data.problem))); }

  function reset() {
    Object.keys(data).forEach(k => { data[k] = ""; });
    Object.values(fields).forEach(el => { el.value = ""; });
    showErrors({}, Object.keys(fields)); syncSelected(); finished = false; doneEl.innerHTML = ""; progress.hidden = false; show(1, false);
  }
  function open(btn) {
    opener = btn || document.activeElement;
    if (finished) reset();
    modal.hidden = false;
    document.documentElement.style.overflow = "hidden";
    show(step, true);
  }
  function close() {
    modal.hidden = true; clearTimeout(advanceTimer);
    document.documentElement.style.overflow = menuOpen ? "hidden" : "";
    if (opener && opener.focus) opener.focus();
  }

  // opening: every CTA button on the page
  document.addEventListener("click", e => { const b = e.target.closest && e.target.closest("[data-open-quote]"); if (b) open(b); });
  modal.addEventListener("click", e => { if (e.target.closest("[data-qm-close]")) close(); });
  backBtn.addEventListener("click", () => { if (typeof step === "number" && step > 1) show(step - 1); });

  // step 1: one tap selects and moves on
  $$("[data-problem]", modal).forEach(b => b.addEventListener("click", () => {
    data.problem = b.dataset.problem; syncSelected();
    clearTimeout(advanceTimer);
    advanceTimer = setTimeout(() => show(2), reducedMotion() ? 0 : 240);
  }));
  // step 2: postcode
  $("[data-form='2']", modal).addEventListener("submit", e => {
    e.preventDefault();
    data.postcode = fields.postcode.value;
    if (Object.keys(check(["postcode"])).length) { fields.postcode.focus(); return; }
    show(3);
  });
  // step 3: name + mobile, then submit through the quote service
  const submitBtn = $("[data-submit]", modal), form3 = $("[data-form='3']", modal);
  function setBusy(b) {
    busy = b; form3.setAttribute("aria-busy", String(b)); submitBtn.setAttribute("aria-disabled", String(b));
    submitBtn.innerHTML = b ? `<span class="spinner" aria-hidden="true"></span><span>Sending...</span>` : esc(CTA_LABEL);
  }
  function renderResult(res) {
    if (res.status === "success") {
      finished = true; progress.hidden = false;
      doneEl.innerHTML = `<div class="q-state" role="status"><div class="ok">${icon("check", 28)}</div>
        <h2 tabindex="-1">Thanks ${esc(res.firstName)}, Callum's team would call you within ${esc(res.callbackWindow)}.</h2>
        <p class="demo">(This is a demonstration site, so no enquiry has been sent.)</p>
        <button type="button" class="btn-navy" data-qm-close>Done</button>
        <button type="button" class="link-btn" data-restart>Start again</button></div>`;
      $("[data-restart]", doneEl).addEventListener("click", () => { reset(); show(1); });
      show("done");
    } else if (res.status === "validation_error") {
      show(3, false); showErrors(res.errors, ["name", "mobile"]);
      const bad = ["name", "mobile"].find(f => res.errors[f]); bad && fields[bad].focus();
    } else {
      doneEl.innerHTML = `<div class="q-state" role="alert"><div class="bad">${icon("alert", 28)}</div>
        <h2 tabindex="-1">We couldn't send that just now</h2>
        <p>${esc(res.message)} Nothing is lost. Please call us instead and Jenny will take your details.</p>
        <p style="margin-top:14px"><a class="big-tel" href="${SITE_CONFIG.phoneHref}">${SITE_CONFIG.phone}</a></p>
        <p class="q-hours">${esc(SITE_CONFIG.hours)}</p>
        ${res.retryable ? `<button type="button" class="link-btn" data-retry>Go back and try again</button>` : ""}</div>`;
      const r = $("[data-retry]", doneEl); r && r.addEventListener("click", () => show(3));
      show("done");
    }
  }
  form3.addEventListener("submit", async e => {
    e.preventDefault();
    if (busy) return;
    data.name = fields.name.value; data.mobile = fields.mobile.value;
    const bad = check(["name", "mobile"]);
    const first = ["name", "mobile"].find(f => bad[f]);
    if (first) { fields[first].focus(); return; }
    const parsed = QuoteSchema.safeParse(data);
    if (!parsed.success) { // an earlier step is invalid (should not happen): send the user back to it
      show(parsed.errors.problem ? 1 : 2); return;
    }
    setBusy(true);
    let result;
    try { result = await quoteService.submitQuote(parsed.data); }
    catch (err) { result = { status: "service_error", message: "Something went wrong on our side.", retryable: true }; }
    setBusy(false);
    renderResult(result);
  });

  // keyboard: Escape closes, Tab stays inside the dialog
  document.addEventListener("keydown", e => {
    if (modal.hidden) return;
    if (e.key === "Escape") { e.preventDefault(); close(); return; }
    if (e.key === "Tab") {
      const f = $$("button:not([disabled]), a[href], input, select", dialog).filter(el => !el.closest("[hidden]") && el.getClientRects().length);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === dialog)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  return { open, close };
}

/* ---------- demo tooling: Laptop / Mobile preview + "simulate error" ---------- */
function initPreview() {
  if (IN_PHONE_FRAME) {
    window.addEventListener("message", ev => {
      if (ev.source === window.parent && ev.data && ev.data.type === "ds-sim") DEMO_FLAGS.simulateError = !!ev.data.value;
    });
    return;
  }
  const pill = document.createElement("div");
  pill.className = "pv-pill"; pill.setAttribute("role", "region"); pill.setAttribute("aria-label", "Demo preview controls");
  pill.innerHTML = `<button type="button" data-mode="laptop" aria-pressed="true">Laptop</button><button type="button" data-mode="mobile" aria-pressed="false">Mobile</button><label><input type="checkbox" data-sim> Simulate error</label>`;
  const stage = document.createElement("div");
  stage.className = "phone-stage";
  stage.innerHTML = `<div class="phone"></div>`;
  document.body.append(stage, pill);
  let frame = null, savedY = 0;
  const post = () => { try { frame && frame.contentWindow.postMessage({ type: "ds-sim", value: DEMO_FLAGS.simulateError }, "*"); } catch (_) { /* frame not ready */ } };
  function mode(m) {
    $$("[data-mode]", pill).forEach(b => b.setAttribute("aria-pressed", String(b.dataset.mode === m)));
    if (m === "mobile") {
      savedY = window.scrollY;
      if (!frame) {
        frame = document.createElement("iframe");
        frame.name = "ds-phone"; frame.title = "Mobile preview of the DryStone website";
        frame.addEventListener("load", post);
        frame.setAttribute("srcdoc", PAGE_SOURCE);
        $(".phone", stage).appendChild(frame);
      }
      document.body.classList.add("phone-mode"); window.scrollTo(0, 0);
    } else {
      document.body.classList.remove("phone-mode"); window.scrollTo(0, savedY);
    }
  }
  pill.addEventListener("click", e => { const b = e.target.closest("[data-mode]"); b && mode(b.dataset.mode); });
  $("[data-sim]", pill).addEventListener("change", e => { DEMO_FLAGS.simulateError = e.target.checked; post(); });
}

/* ---------- boot ---------- */
(function boot() {
  $("#app").innerHTML = renderPage();
  renderJsonLd();
  const menu = initMenu();
  initNav(menu); initCtaGlow(); initFaq(); initSlider(); initBeforeAfter(); initMotion(); initQuoteModal();
})();
