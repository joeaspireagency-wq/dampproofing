/* =====================================================================
   01. SITE CONFIG + CONTENT (everything a real business would replace)
   All of this is SAMPLE content for a fictional business.
   ===================================================================== */

/**
 * @typedef {{ id:string, icon:string, title:string, plain?:string, signs:string, action:string, time:string, guarantee:string }} Service
 * @typedef {{ id:string, name:string, price:string, priceLead?:string, forWho:string, features:string[], popular?:boolean }} Package
 * @typedef {{ q:string, a:string }} Faq
 * @typedef {{ name:string, area:string, service:string, date:string, stars:number, text:string }} Review
 */

const CTA_LABEL = "Get Your Free Quote";

const SITE_CONFIG = Object.freeze({
  name: "DryStone Damp Specialists",
  short: "DryStone",
  tagline: "The honest damp survey.",
  owner: { name: "Callum Reeves", role: "Owner and lead surveyor" },
  phone: "+44 7340 845721",
  phoneHref: "tel:+447340845721",
  whatsappHref: "https://wa.me/447340845721",
  email: "hello@drystonedamp.example",
  hours: "Mon to Sat, 8am to 6pm. Emergency callouts for leaks and flooding.",
  city: "Bristol",
  ctaLabel: CTA_LABEL,
  ctaMicro: "Free survey included. No obligation. Fixed-price written quote within 48 hours.",
  companyNo: "Registered in England and Wales No. 00000000 (placeholder)",
  nav: [
    { label: "What we fix", href: "#what-we-fix" },
    { label: "Prices", href: "#pricing" },
    { label: "About Callum", href: "#about" },
    { label: "Reviews", href: "#reviews" },
    { label: "FAQ", href: "#faq" }
  ],
  neighbourhoods: ["Clifton", "Redland", "Southville", "Bedminster", "Totterdown", "Horfield"],
  towns: ["Bristol", "Bath", "Keynsham", "Portishead", "South Gloucestershire"],
  /** The six locations shown in the "Areas we cover" section. Edit freely. */
  featuredAreas: ["Bristol", "Clifton", "Bath", "Keynsham", "Portishead", "South Gloucestershire"],
  postcodes: "BS1 to BS16"
});

const PROBLEMS = Object.freeze([
  "Mould or black spots", "Tide marks or damp patches", "Musty smell",
  "Peeling paint or plaster", "Cellar or basement damp", "Not sure"
]);

const CONTENT = {
  symptoms: [
    { id: "mould", title: "Black mould in corners", text: "Often condensation, not rising damp. A survey shows which, and what to change.", alt: "Illustration of a wall corner with black mould spots and a window with condensation" },
    { id: "tide", title: "Tide marks on walls", text: "A stain that stops at a clear line, low on the wall, with white salt marks.", alt: "Illustration of a wall with a brown tide mark and salt staining above the skirting board" },
    { id: "peel", title: "Peeling paint or plaster", text: "Paint blistering or plaster crumbling away, usually near the floor.", alt: "Illustration of a wall with flaking, peeling paint exposing plaster underneath" },
    { id: "musty", title: "A musty smell", text: "That damp, earthy smell in a room, cupboard or cellar that never quite goes.", alt: "Illustration of a cupboard with its door ajar and faint vapour lines in a damp-smelling room" }
  ],
  steps: [
    { n: 1, title: "Request your free quote", text: "Fill in four quick fields. Jenny from the office calls you to find a time that suits.", tag: "Takes 30 seconds" },
    { n: 2, title: "Callum surveys and tells you the real cause", text: "He checks the walls, the air and the outside of your home. You get moisture readings and photos.", tag: "Readings and photos" },
    { n: 3, title: "You get a fixed-price written quote", text: "It lands within 48 hours of the survey. No pressure to say yes. Take it home and think about it.", tag: "Within 48 hours" }
  ],
  /** @type {Service[]} */
  services: [
    { id: "rising-damp", short: "Damp barrier injected along the wall base, then dried out.", icon: "droplet", title: "Rising damp", plain: "Damp proof course (DPC): a barrier that stops moisture rising up your walls.", signs: "Tide marks up to 1m, salt staining, peeling paint low on walls.", action: "Inject a damp proof barrier along the wall base, then dry it out.", time: "1 to 2 days", guarantee: "20-year guarantee" },
    { id: "penetrating-damp", short: "Find and fix the water entry: gutters, pointing, render.", icon: "rain", title: "Penetrating damp", signs: "Damp patches after rain, stains on chimney breasts or gable walls.", action: "Find and fix the water entry: gutters, pointing, render, flashing.", time: "1 to 3 days", guarantee: "Workmanship guarantee" },
    { id: "condensation", short: "Fix ventilation and moisture sources, then clean the mould.", icon: "wind", title: "Condensation and mould", plain: "Condensation: moisture in the air settling on cold walls and windows.", signs: "Black mould in corners, wet windows, worse in winter.", action: "Fix ventilation, extraction and moisture sources, then treat and clean mould.", time: "1 day", guarantee: "Workmanship guarantee" },
    { id: "cellar-tanking", short: "Waterproof walls and floor with tanking or a drainage membrane.", icon: "waves", title: "Cellar and basement tanking", plain: "Tanking: a waterproof lining applied to cellar walls and floor.", signs: "Damp or flooding below ground, white salt crust, musty smell.", action: "Waterproof the walls and floor with tanking slurry or a drainage membrane system.", time: "1 to 3 weeks", guarantee: "20-year guarantee" },
    { id: "replastering", short: "Strip damaged plaster, then salt-resistant render and skim.", icon: "brick", title: "Replastering and salt-resistant render", signs: "Crumbling or blown plaster after damp treatment.", action: "Strip affected plaster, apply salt-resistant render, skim ready to decorate.", time: "2 to 4 days", guarantee: "Workmanship guarantee" },
    { id: "timber", short: "Survey, treat and replace affected timber.", icon: "bug", title: "Timber treatment (woodworm and dry rot)", signs: "Small exit holes, crumbling or cracked skirting and joists, mushroomy smell.", action: "Survey, treat and replace affected timber.", time: "1 to 4 days", guarantee: "Workmanship guarantee" }
  ],
  includes: [
    "Free survey with photo report", "Fixed-price written quote",
    "Protection sheets and daily clean-up", "Written guarantee certificate"
  ],
  /** @type {Package[]} */
  packages: [
    { id: "targeted", name: "Targeted Fix", priceLead: "From", price: "£450", forWho: "One wall or one problem area, e.g. a DPC wall or a condensation fix.", features: ["Free survey and photo report", "Fixed price, itemised in writing", "Guarantee included (20 years on DPC work)"] },
    { id: "whole-home", name: "Whole-Home Damp Protection", priceLead: "Typically", price: "£1,500 to £3,500", forWho: "A standard terraced or semi-detached home.", popular: true, features: ["DPC injection to all affected walls", "Salt-resistant replastering", "20-year insurance-backed guarantee"] },
    { id: "cellar", name: "Cellar and Basement Waterproofing", priceLead: "Typically", price: "£3,000 to £6,000", forWho: "Depends on size. The survey confirms the right system.", features: ["Tanking system for walls and floor", "Sump and pump if needed", "20-year insurance-backed guarantee"] }
  ],
  reassure: [
    "Valid for 30 days", "Small deposit to book, balance on completion", "No hidden extras"
  ],
  badges: [
    { icon: "usercheck", label: "Qualified Surveyor" },
    { icon: "shield", label: "Insurance-Backed Guarantee" },
    { icon: "umbrella", label: "Fully Insured" }
  ],
  callum: {
    heading: "Meet Callum. He'll tell you straight.",
    story: [
      "I spent my twenties as a bricklayer, then retrained as a damp surveyor after seeing too many homes fixed with the wrong treatment. About half the damp I'm called to isn't rising damp at all. If that's yours, I'll tell you how to fix it, and you won't pay me a penny."
    ],
    promise: "We'll tell you if you don't need us."
  },
  caseStudy: {
    heading: "A result: Victorian terrace, Southville",
    tag: "Demonstration project (fictional)",
    stats: [
      { label: "The problem", text: "Tide marks up to 1.1m, peeling paint, musty front room." },
      { label: "The diagnosis", text: "Failed damp proof course, plus ground raised above its original level." },
      { label: "The fix", text: "DPC injection along 14m, salt-resistant replaster, ground lowered, air bricks cleared." }
    ],
    result: { from: "38%", to: "11%", text: "After 6 weeks. 3 days on site. Fixed price £2,350. 20-year guarantee." },
    quote: "We'd lived with that smell for years. Callum showed us the readings, explained it was the raised ground outside as much as the wall, and fixed both.",
    cite: "Priya and James, Southville (sample quote)"
  },
  rating: { score: "4.9", count: 112 },
  /** @type {Review[]} */
  reviews: [
    { name: "Priya", area: "Southville", service: "Rising damp", date: "March 2026", stars: 5, text: "Three firms told me different things. Callum was the only one who showed me the moisture readings and explained why. Fixed price, three days, no mess. Walls are bone dry." },
    { name: "Mark", area: "Bath", service: "Condensation", date: "January 2026", stars: 5, text: "I expected a big bill. Callum found it was condensation and showed me what to change. He charged nothing for the visit. Obviously we used them when we needed the cellar done." },
    { name: "Sarah", area: "Clifton", service: "Cellar tanking", date: "February 2026", stars: 5, text: "Our cellar flooded every winter. Two weeks of work, tidy every evening, and it's been dry through two storms since." },
    { name: "Dave", area: "Keynsham", service: "Penetrating damp", date: "April 2026", stars: 5, text: "The quote arrived in 24 hours and the price on the day was the price on the quote. Refreshing." },
    { name: "Helen", area: "Redland", service: "Replastering", date: "May 2026", stars: 5, text: "They replastered the whole front room so well I couldn't tell where the damp patch was. Left it cleaner than they found it." },
    { name: "Tom and Aisha", area: "Bedminster", service: "House sale", date: "June 2026", stars: 5, text: "Our buyer's survey flagged damp days before exchange. DryStone surveyed within 48 hours and sorted it. Sale went through." }
  ],
  /** @type {Faq[]} */
  faqs: [
    { q: "Is the survey really free? What's the catch?", a: "No catch. The survey is free and there's no obligation to book any work. You get a written report either way. If we find it's condensation or something you can fix yourself, we'll tell you how. We win work by being honest." },
    { q: "How much will it cost, and will the price go up?", a: "Most homes cost £1,500 to £3,500 for a full treatment including replastering; single areas start from £450. After the survey you get a fixed-price written quote, itemised and valid for 30 days. If we find something extra during the work, we stop and agree it with you first. You never get a surprise bill." },
    { q: "How do I know it's really damp, not just condensation?", a: "We test, not guess. Callum uses a moisture meter and checks the wall, the air and the outside of your home. You get a photo report showing the readings and the cause. About half the 'damp' calls we visit turn out to be condensation or a gutter fault." },
    { q: "Will it be messy? Do I need to move out?", a: "No need to move out. Most jobs are 1 to 3 days. We lay dust sheets, seal off the work area and clean up every day. Cellar work takes longer but the rest of the house stays usable. We'll tell you beforehand which furniture to move away from the walls." },
    { q: "Will the damp come back? What does the guarantee cover?", a: "Our DPC and tanking work comes with a 20-year insurance-backed guarantee. It covers the treated areas and the cause identified in your survey report, and it's transferable if you sell. Full terms come with your quote. We fix the cause, not just the stain." },
    { q: "How soon can you come, and how long does it take?", a: "We can usually survey within 3 to 5 working days, and emergencies (leaks, flooding) sooner. Your quote arrives within 48 hours of the survey. Typical jobs take 1 to 3 days on site; cellars take 1 to 3 weeks." },
    { q: "How do I know you're not just trying to sell me work?", a: "Fair question. You get a written report with photos and readings, so you can check our diagnosis or show it to another firm. We'll say when you don't need us. Our guarantee is insurance-backed, so it stands even if we ever close. And there's no pressure: take the quote home and think about it." }
  ]
};

/** Light content validation at start-up (stand-in for build-time schema validation). */
(function validateContent() {
  const problems = [];
  if (CONTENT.services.length !== 6) problems.push("expected 6 services");
  if (CONTENT.packages.filter(p => p.popular).length !== 1) problems.push("exactly one package must be popular");
  if (CONTENT.faqs.length !== 7) problems.push("expected 7 FAQs");
  if (CONTENT.reviews.length !== 6) problems.push("expected 6 reviews");
  CONTENT.reviews.forEach((r, i) => { if (!(r.stars >= 1 && r.stars <= 5) || !r.text) problems.push("review " + i + " invalid"); });
  if (problems.length) console.warn("[content] " + problems.join("; "));
})();

/* =====================================================================
   02. QUOTE FORM SCHEMA + QUOTE SERVICE (swappable, no network)
   ===================================================================== */

/**
 * @typedef {{ name:string, mobile:string, postcode:string, problem:string }} QuotePayload
 * @typedef {{ status:"success", firstName:string, callbackWindow:string, demo:true }} QuoteSuccess
 * @typedef {{ status:"validation_error", errors:Record<string,string> }} QuoteValidationError
 * @typedef {{ status:"service_error", message:string, retryable:boolean }} QuoteServiceError
 * @typedef {QuoteSuccess|QuoteValidationError|QuoteServiceError} QuoteResult
 * @typedef {{ submitQuote:(payload:QuotePayload)=>Promise<QuoteResult> }} QuoteService
 */

const UK_MOBILE = /^(?:07\d{9}|\+?447\d{9}|00447\d{9})$/;
const UK_POSTCODE = /^(GIR ?0AA|[A-PR-UWYZ]([0-9]{1,2}|([A-HK-Y][0-9]([0-9ABEHMNPRV-Y])?)|[0-9][A-HJKPS-UW]) ?[0-9][ABD-HJLNP-UW-Z]{2})$/i;

/** Zod-style schema: returns { success:true, data } or { success:false, errors:{ field: message } } */
const QuoteSchema = {
  fields: ["name", "mobile", "postcode", "problem"],
  safeParse(input) {
    const errors = {};
    const name = String(input.name || "").trim();
    const mobile = String(input.mobile || "").replace(/[\s\-()]/g, "");
    const postcode = String(input.postcode || "").trim().toUpperCase().replace(/\s+/g, "");
    const problem = String(input.problem || "");
    if (name.length < 2) errors.name = "Please enter your name so we know who to ask for.";
    else if (name.length > 80) errors.name = "That name looks too long. Please shorten it.";
    if (!mobile) errors.mobile = "Please enter your mobile number.";
    else if (!UK_MOBILE.test(mobile)) errors.mobile = "That doesn't look like a UK mobile. It should start 07, for example 07700 900123.";
    if (!postcode) errors.postcode = "Please enter your postcode.";
    else if (!UK_POSTCODE.test(postcode)) errors.postcode = "That doesn't look like a UK postcode. For example BS3 1AB.";
    if (!PROBLEMS.includes(problem)) errors.problem = "Please choose the closest match. \"Not sure\" is fine.";
    if (Object.keys(errors).length) return { success: false, errors };
    const pc = postcode.replace(/^(.+?)(\d[A-Z]{2})$/, "$1 $2");
    return { success: true, data: { name, mobile, postcode: pc, problem } };
  }
};

const sleep = ms => new Promise(r => setTimeout(r, ms));

/**
 * DEMO IMPLEMENTATION. Makes NO network request and stores, logs and transmits NOTHING.
 *
 * To go live later, write another object with the same shape (QuoteService) that, for example, POSTs the
 * validated payload to a form service (Formspree, Getform, a Next.js route handler, your CRM's webhook) and
 * maps the response to one of the three QuoteResult variants. Then change `quoteService` below. The UI needs no
 * other change: it only reads `result.status`.
 * @type {QuoteService}
 */
const demoQuoteService = {
  async submitQuote(payload) {
    try {
      const parsed = QuoteSchema.safeParse(payload);
      if (!parsed.success) return { status: "validation_error", errors: parsed.errors };
      await sleep(900 + Math.random() * 500);          // simulated latency only
      if (DEMO_FLAGS.simulateError) {                    // demo control: preview the fallback state
        return { status: "service_error", message: "Our enquiry system isn't responding right now.", retryable: true };
      }
      return { status: "success", firstName: parsed.data.name.split(/\s+/)[0], callbackWindow: "2 working hours", demo: true };
    } catch (err) {
      return { status: "service_error", message: "Something went wrong on our side.", retryable: true };
    }
  }
};
/** @type {QuoteService} */
const quoteService = demoQuoteService;
const DEMO_FLAGS = { simulateError: false };
