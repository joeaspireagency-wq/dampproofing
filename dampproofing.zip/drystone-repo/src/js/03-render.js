/* =====================================================================
   07. RENDER: one function per section, all driven by SITE_CONFIG + CONTENT
   ===================================================================== */
const esc = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** The ONE primary CTA. Same label everywhere; every instance opens the same quote popup. Only used in the hero, the final band and the footer. */
const ctaButton = (extra = "") => `<button type="button" class="cta ${extra}" data-open-quote aria-haspopup="dialog">${esc(CTA_LABEL)}</button>`;
const telLink = (cls = "") => `<a class="${cls}" href="${SITE_CONFIG.phoneHref}">${SITE_CONFIG.phone}</a>`;

function renderHeader() {
  const nav = SITE_CONFIG.nav.map(n => `<a href="${n.href}">${esc(n.label)}</a>`).join("");
  const mnav = SITE_CONFIG.nav.map(n => `<a class="m-link" href="${n.href}">${esc(n.label)}${icon("right", 20)}</a>`).join("");
  return `<a class="skip-link" href="#main">Skip to content</a>
  <header class="site-header" id="site-header">
    <div class="container header-inner">
      <a class="wordmark" href="#top">${LOGO_MARK}<span><b>${SITE_CONFIG.short}</b> <small>Damp Specialists</small></span></a>
      <nav class="header-nav" aria-label="Main">${nav}</nav>
      <div class="header-right">
        <a class="tel" href="${SITE_CONFIG.phoneHref}">${icon("phone", 18)}${SITE_CONFIG.phone}</a>
        <a class="icon-btn tel-icon-btn" href="${SITE_CONFIG.phoneHref}" aria-label="Call ${SITE_CONFIG.phone}">${icon("phone", 22)}</a>
        <button class="icon-btn menu-btn" id="menu-btn" type="button" aria-expanded="false" aria-controls="mobile-menu" aria-label="Open menu">${icon("menu", 24)}</button>
      </div>
    </div>
    <div class="mobile-menu" id="mobile-menu" role="dialog" aria-label="Menu">
      <nav aria-label="Mobile">${mnav}</nav>
      <div class="m-foot">
        <a class="tel m-tel" href="${SITE_CONFIG.phoneHref}" style="display:inline-flex">${icon("phone", 20)}${SITE_CONFIG.phone}</a>
      </div>
    </div>
  </header>`;
}

function renderQuoteModal() {
  const thumbs = { "Mould or black spots": "symptom-mould", "Tide marks or damp patches": "symptom-tide", "Musty smell": "symptom-musty", "Peeling paint or plaster": "symptom-peel" };
  const opts = PROBLEMS.map(p => {
    const key = thumbs[p];
    const thumb = key ? `<span class="thumb">${imageSvg(key).replace(/role="img" aria-label="[^"]*"/, 'aria-hidden="true"')}</span>` : `<span class="thumb ic">${icon(p === "Not sure" ? "search" : "waves", 24)}</span>`;
    return `<button type="button" class="qm-opt" data-problem="${esc(p)}" aria-pressed="false">${thumb}<span>${esc(p)}</span>${icon("right", 20, "chev")}</button>`;
  }).join("");
  const bars = [1, 2, 3].map(() => "<i></i>").join("");
  return `<div class="modal" id="quote-modal" hidden>
    <div class="modal-backdrop" data-qm-close></div>
    <div class="modal-dialog" role="dialog" aria-modal="true" aria-label="${esc(CTA_LABEL)}" tabindex="-1">
      <div class="qm-top">
        <button type="button" class="icon-btn" data-qm-back aria-label="Back to the previous step" hidden>${icon("left", 22)}</button>
        <div class="qm-progress"><div class="qm-bar" aria-hidden="true">${bars}</div><span class="qm-steptext" data-qm-steptext aria-live="polite">Step 1 of 3</span></div>
        <button type="button" class="icon-btn" data-qm-close aria-label="Close">${icon("x", 22)}</button>
      </div>
      <div class="qm-body">
        <section class="qm-step" data-step="1">
          <h2 tabindex="-1">What's the problem?</h2>
          <p class="qm-lead">Tap the closest match. We'll take you to the next step automatically.</p>
          <div class="qm-options">${opts}</div>
          <p class="qm-fine">Not sure? Choose "Not sure". That's exactly what the survey is for.</p>
        </section>
        <section class="qm-step" data-step="2" hidden>
          <h2 tabindex="-1">Where is the property?</h2>
          <p class="qm-lead">Just the postcode, so we know you're in our area. Takes 30 seconds.</p>
          <form novalidate data-form="2">
            <div class="field"><label for="q-postcode">Postcode</label>
              <input id="q-postcode" name="postcode" type="text" autocomplete="postal-code" placeholder="BS3 1AB" aria-describedby="q-postcode-err" required>
              <p class="err" id="q-postcode-err" aria-live="polite"></p></div>
            <button type="submit" class="btn-navy">Continue ${icon("arrow", 20)}</button>
          </form>
        </section>
        <section class="qm-step" data-step="3" hidden>
          <h2 tabindex="-1">Who should Callum's team call?</h2>
          <p class="qm-lead">We'll ring to find a survey time that suits you.</p>
          <form novalidate data-form="3">
            <div class="field"><label for="q-name">Name</label>
              <input id="q-name" name="name" type="text" autocomplete="name" aria-describedby="q-name-err" required>
              <p class="err" id="q-name-err" aria-live="polite"></p></div>
            <div class="field"><label for="q-mobile">Mobile number</label>
              <input id="q-mobile" name="mobile" type="tel" inputmode="tel" autocomplete="tel" placeholder="07700 900123" aria-describedby="q-mobile-err" required>
              <p class="err" id="q-mobile-err" aria-live="polite"></p></div>
            <button type="submit" class="cta cta--block" data-submit>${esc(CTA_LABEL)}</button>
            <p class="qm-fine">${esc(SITE_CONFIG.ctaMicro)}</p>
            <p class="qm-demo">Demonstration form. Nothing you type is sent, stored or logged.</p>
          </form>
        </section>
        <section class="qm-step" data-step="done" hidden data-done></section>
        <p class="qm-call">Prefer to talk? Call <a href="${SITE_CONFIG.phoneHref}">${SITE_CONFIG.phone}</a></p>
      </div>
    </div>
  </div>`;
}

function renderHero() {
  const ticks = ["Free survey, no obligation", "20-year insurance-backed guarantee", "We'll tell you if you don't need us"]
    .map(t => `<li><span class="tick-dot">${icon("check", 15)}</span>${esc(t)}</li>`).join("");
  return `<section class="section hero bg-navy on-navy" id="top" aria-labelledby="hero-h">
    <div class="hero-bg"><img class="hero-photo" src="__HERO_IMG__" alt="" aria-hidden="true" width="1000" height="833" decoding="async"><div class="hero-scrim"></div>${shapesHtml("hero")}</div>
    <div class="container">
      <div class="hero-grid">
        <div class="hero-copy">
          <span class="label">Damp surveys in Bristol and Bath</span>
          <h1 id="hero-h">Damp on your walls? Find out what's really causing it.</h1>
          <p class="sub">A free survey from a qualified surveyor. Honest advice and a fixed-price written quote within 48 hours.</p>
          <ul class="ticks">${ticks}</ul>
          <div class="hero-actions">${ctaButton()}<p class="micro">${esc(SITE_CONFIG.ctaMicro)}</p></div>
          <p class="hero-phone">Prefer to talk? Call ${telLink()}</p>
        </div>
      </div>
    </div>
  </section>`;
}

function renderSymptoms() {
  const cards = CONTENT.symptoms.map(s => {
    const key = "symptom-" + s.id;
    IMAGES[key].alt = s.alt;
    return `<article class="card symptom"><div class="ph">${s.id === "mould" ? `<img src="__MOULD_IMG__" width="720" height="535" alt="${esc(s.alt)}" loading="lazy" decoding="async">` : s.id === "tide" ? `<img class="tide-img" src="__TIDE_IMG__" width="720" height="538" alt="${esc(s.alt)}" loading="lazy" decoding="async">` : s.id === "peel" ? `<img class="peel-img" src="__PEEL_IMG__" width="640" height="478" alt="${esc(s.alt)}" loading="lazy" decoding="async">` : s.id === "musty" ? `<img class="musty-img" src="__MUSTY_IMG__" width="640" height="478" alt="${esc(s.alt)}" loading="lazy" decoding="async">` : imageSvg(key)}</div>
      <div class="body"><h3>${esc(s.title)}</h3><p>${esc(s.text)}</p></div></article>`;
  }).join("");
  return `<section class="section bg-off light" id="symptoms" aria-labelledby="sym-h"><div class="container">
    <div class="section-head section-head--center"><h2 id="sym-h">Is this your problem?</h2><p>These are the signs people usually notice first. Most of them have a simple cause.</p></div>
    <div class="grid symptom-grid">${cards}</div>
    <p class="notsure">Not sure? That's what the survey is for.</p></div></section>`;
}

function renderHow() {
  const steps = CONTENT.steps.map(s => `<li class="card step"><div class="num" aria-hidden="true">${s.n}</div><h3>${esc(s.title)}</h3><p>${esc(s.text)}</p><span class="chip">${icon("clock", 14)}${esc(s.tag)}</span></li>`).join("");
  return `<section class="section bg-white light" id="how" aria-labelledby="how-h"><div class="container">
    <div class="section-head section-head--center"><h2 id="how-h">How it works</h2><p>Three steps. No pressure.</p></div>
    <ol class="grid steps" style="list-style:none;padding:0;margin:0">${steps}</ol></div></section>`;
}

function renderServices() {
  const cards = CONTENT.services.map(s => `<article class="card svc" id="svc-${s.id}">
    <div class="svc-top"><span class="tile">${icon(s.icon, 26)}</span><h3>${esc(s.title)}</h3></div>
    <p class="svc-short">${esc(s.short)}</p>
    <div class="g"><span class="tick-dot">${icon("check", 12)}</span>${esc(s.guarantee)} · ${esc(s.time)}</div>
    </article>`).join("");
  const inc = CONTENT.includes.map(i => `<li>${icon("check", 20)}<span>${esc(i)}</span></li>`).join("");
  return `<section class="section bg-off light" id="what-we-fix" aria-labelledby="wf-h"><div class="container">
    <div class="section-head section-head--center"><h2 id="wf-h">What we fix</h2><p>Plain English, so you know what's happening to your home.</p></div>
    <div class="grid svc-grid">${cards}</div>
    <div class="card includes"><h3>Every job includes</h3><ul class="inc-grid">${inc}</ul></div></div></section>`;
}

function renderPricing() {
  const cards = CONTENT.packages.map(p => `<article class="card pkg ${p.popular ? "pop" : ""}" aria-label="${esc(p.name)}">
    ${p.popular ? `<span class="flag">Most popular</span>` : ""}
    <h3>${esc(p.name)}</h3><p class="for">${esc(p.forWho)}</p>
    <div class="price"><small>${esc(p.priceLead)}</small>${esc(p.price)}</div>
    <ul>${p.features.map(f => `<li>${icon("check", 20)}<span>${esc(f)}</span></li>`).join("")}</ul></article>`).join("");
  return `<section class="section bg-white light" id="pricing" aria-labelledby="pr-h"><div class="container">
    <div class="section-head section-head--center"><h2 id="pr-h">Straight prices, no surprises.</h2></div>
    <div class="card anchor-panel"><span class="tile">${icon("search", 24)}</span><p>A damp survey usually costs £150 to £350. With us it's free.</p></div>
    <div class="grid pkg-grid">${cards}</div>
    <ul class="reassure">${CONTENT.reassure.map(r => `<li>${icon("check", 20)}<span>${esc(r)}</span></li>`).join("")}</ul>
    </div></section>`;
}

function renderCallum() {
  const c = CONTENT.callum;
  return `<section class="section bg-off light" id="about" aria-labelledby="c-h">${shapesHtml("callum")}<div class="container"><div class="callum-grid">
    <div class="portrait"><img src="__OWNER_IMG__" width="720" height="869" alt="${esc(SITE_CONFIG.owner.name)} kneeling by an exposed brick wall, drilling a damp proof course" decoding="async"></div>
    <div class="callum-copy"><span class="label">${esc(SITE_CONFIG.owner.name)}, ${esc(SITE_CONFIG.owner.role.toLowerCase())}</span>
      <h2 id="c-h">${esc(c.heading)}</h2><div style="margin-top:12px">${c.story.map(p => `<p>${esc(p)}</p>`).join("")}</div>
      <p class="pull">${esc(c.promise)}</p>
      <div class="sig"><svg viewBox="0 0 120 44" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 30c-8-10-2-24 8-24 6 0 8 6 3 12-5 7-4 14 2 14 7 0 10-12 12-16-3 8-1 16 4 14 4-2 6-8 8-12-1 6 1 12 5 11 6-1 7-14 12-14 4 0 3 8 7 8 4 0 6-8 10-6"/><path d="M14 38c24-4 60-3 98-1"/></svg>
      <span><b>${esc(SITE_CONFIG.owner.name)}</b>${esc(SITE_CONFIG.owner.role)}</span></div>
      </div></div></div></section>`;
}

function renderCase() {
  const c = CONTENT.caseStudy;
  const stats = c.stats.map(s => `<div class="card stat"><h3>${esc(s.label)}</h3><p>${esc(s.text)}</p></div>`).join("");
  return `<section class="section bg-white light" id="results" aria-labelledby="cs-h">${shapesHtml("case")}<div class="container">
    <div class="case-head"><h2 id="cs-h">${esc(c.heading)}</h2></div>
    <div class="ba" id="ba" data-ba>
      <div class="after-layer" style="position:absolute;inset:0"><img src="__AFTER_IMG__" width="800" height="597" alt="The same wall after treatment: clean, dry and freshly decorated, with the moisture meter reading 11 percent" decoding="async" draggable="false"></div>
      <div class="before-layer" data-ba-before><img src="__BEFORE_IMG__" width="800" height="597" alt="The wall before treatment: damp staining, salt deposits and blown plaster, with the moisture meter reading 38 percent" decoding="async" draggable="false"></div>
      <span class="lab l" aria-hidden="true">Before</span><span class="lab r" aria-hidden="true">After</span>
      <div class="handle" data-ba-handle role="slider" tabindex="0" aria-label="Before and after comparison" aria-orientation="horizontal" aria-valuemin="0" aria-valuemax="100" aria-valuenow="50" aria-valuetext="Showing 50 percent before, 50 percent after"><div class="knob">${icon("arrows", 22)}</div></div>
    </div>
    
    <div class="grid stat-grid">${stats}
      <div class="card stat result"><h3>The result</h3><div class="big-nums" aria-label="Moisture reading fell from ${c.result.from} to ${c.result.to}"><span>${c.result.from}</span><span class="arr" aria-hidden="true">to</span><span>${c.result.to}</span></div><p>${esc(c.result.text)}</p></div></div>
    <figure class="quote-block" style="margin-inline:auto"><blockquote>&ldquo;${esc(c.quote)}&rdquo;</blockquote><cite>${esc(c.cite)}</cite></figure></div></section>`;
}

function renderReviews() {
  const slides = CONTENT.reviews.map((r, i) => `<div class="t-slide" data-slide="${i}"><article class="card review">
    ${stars(r.stars, 18)}<blockquote>&ldquo;${esc(r.text)}&rdquo;</blockquote>
    <div class="meta"><span class="who">${esc(r.name)}, ${esc(r.area)}</span><span>${esc(r.service)}</span><span aria-hidden="true">&middot;</span><span>${esc(r.date)}</span></div></article></div>`).join("");
  return `<section class="section bg-off light" id="reviews" aria-labelledby="rv-h"><div class="container">
    <div class="section-head section-head--center" style="margin-bottom:24px"><h2 id="rv-h">What Bristol homeowners say</h2></div>

    <div class="t-wrap" data-slider>
      <div class="t-viewport" tabindex="0" role="group" aria-roledescription="carousel" aria-label="Customer reviews. Use the left and right arrow keys to move between reviews." data-viewport>
        <div class="t-track" data-track aria-live="polite">${slides}</div></div>
      <div class="t-controls">
        <button class="arrow" type="button" data-prev aria-label="Previous review">${icon("left", 24)}</button>
        <div class="dots" data-dots></div>
        <button class="arrow" type="button" data-next aria-label="Next review">${icon("right", 24)}</button>
        <p class="sr-only" data-count aria-live="polite">Review 1 of ${CONTENT.reviews.length}</p>
      </div></div></div></section>`;
}

function renderAreas() {
  const tiles = SITE_CONFIG.featuredAreas.map(a => `<li class="area-tile"><span class="pin">${icon("pin", 18)}</span>${esc(a)}</li>`).join("");
  return `<section class="section areas bg-white light" id="areas" aria-labelledby="ar-h"><div class="container"><div class="areas-wrap">
    <div class="areas-intro"><h2 id="ar-h">Areas we cover</h2><p>A local team, so you don't wait weeks for a visit. Just outside the list? Call ${telLink("textlink")} and we'll tell you straight if we can help.</p></div>
    <ul class="areas-six" aria-label="Areas we cover">${tiles}</ul></div></div></section>`;
}

function renderFaq() {
  const items = CONTENT.faqs.map((f, i) => `<div class="card faq-item"><h3><button class="faq-q" type="button" id="faq-b${i}" aria-expanded="${i === 0}" aria-controls="faq-p${i}" data-faq-btn>${esc(f.q)}${icon("down", 22)}</button></h3>
    <div class="faq-panel ${i === 0 ? "is-open" : ""}" id="faq-p${i}" role="region" aria-labelledby="faq-b${i}" ${i === 0 ? "" : "inert"}><div><p>${esc(f.a)}</p></div></div></div>`).join("");
  return `<section class="section bg-off light" id="faq" aria-labelledby="fq-h"><div class="container">
    <div class="section-head section-head--center"><h2 id="fq-h">Questions you might have</h2></div>
    <div class="faq" data-faq>${items}</div></div></section>`;
}

function renderFinal() {
  return `<section class="section final bg-navy on-navy" id="final-cta" aria-labelledby="fn-h" data-final>${shapesHtml("final")}<div class="container">
    <h2 id="fn-h">Ready to get to the bottom of it?</h2>
    <div class="cta-row">${ctaButton()}<p class="phone-line">Or call ${telLink()}</p></div></div></section>`;
}

function renderFooter() {
  const svc = CONTENT.services.map(s => `<li><a href="#svc-${s.id}">${esc(s.title.replace(/ \(.*\)/, ""))}</a></li>`).join("");
  const badges = CONTENT.badges.map(b => `<div class="badge"><span class="tile">${icon(b.icon, 18)}</span><span>${esc(b.label)}</span></div>`).join("");
  return `<footer class="footer on-navy" id="footer">
    <a class="foot-phone" href="${SITE_CONFIG.phoneHref}" aria-label="Call ${SITE_CONFIG.phone}">${icon("phone", 20)}</a>
    <div class="container"><div class="foot-grid">
      <div><a class="wordmark" href="#top">${LOGO_MARK}<span><b>${SITE_CONFIG.short}</b> <small>Damp Specialists</small></span></a>
        <p style="margin-top:16px;max-width:30ch">${esc(SITE_CONFIG.tagline)} We'll tell you straight if you don't need us.</p>
        <div class="foot-contact"><div>${icon("phone", 18)}${telLink()}</div><div>${icon("mail", 18)}<span>${SITE_CONFIG.email}</span></div><div>${icon("clock", 18)}<span>${esc(SITE_CONFIG.hours)}</span></div></div></div>
      <div><h3>Services</h3><ul>${svc}</ul></div>
      <div><h3>Areas covered</h3><ul><li>Bristol (${SITE_CONFIG.postcodes})</li><li>Bath</li><li>Keynsham</li><li>Portishead</li><li>South Gloucestershire</li></ul>
        <p style="margin-top:12px;font-size:.9rem">${SITE_CONFIG.neighbourhoods.join(", ")}</p></div>
      <div><h3>Credentials</h3><div class="foot-badges">${badges}</div>${ctaButton()}</div>
    </div>
    <div class="foot-bottom"><div class="demo-banner" role="note"><strong>Demonstration website.</strong> DryStone Damp Specialists is a fictional business and all content is sample content.</div>
      <div class="links"><span>&copy; ${new Date().getFullYear()} DryStone Damp Specialists</span><span>${esc(SITE_CONFIG.companyNo)}</span>
        <a href="#" data-placeholder>Privacy Policy</a><a href="#" data-placeholder>Cookies</a><a href="#" data-placeholder>Terms</a></div></div></div></footer>`;
}

/** Floating contact button (laptop and tablet widths). Icon is a generic chat bubble: swap in your own brand asset. */
function renderContactFloat() {
  return `<aside aria-label="Quick contact"><a class="wa" id="contact-float" href="${SITE_CONFIG.whatsappHref}" target="_blank" rel="noopener noreferrer" aria-label="Contact us on WhatsApp (opens in a new tab)">
    <span class="wa-label">Contact us</span><span class="wa-btn">${icon("chat", 30)}</span></a></aside>`;
}

function renderPage() {
  // Order and divider map documented at the top of this file and in the HTML comment.
  const D = dividerHtml;
  return renderHeader() + `<main id="main">` +
    renderHero() + D("B", "navy", "off") +
    renderSymptoms() + D("C", "off", "white") +
    renderHow() + D("A", "white", "off") +
    renderServices() + D("C", "off", "white") +
    renderPricing() + D("B", "white", "off") +
    renderCallum() + D("B", "off", "white") +
    renderCase() + D("A", "white", "off") +
    renderReviews() + D("C", "off", "white") +
    renderAreas() + D("A", "white", "off") +
    renderFaq() + D("B", "off", "navy") +
    renderFinal() + D("B", "navy", "deep") +
    `</main>` + renderFooter() + renderContactFloat() + renderQuoteModal();
}

function renderJsonLd() {
  const local = { "@context": "https://schema.org", "@type": "LocalBusiness", name: SITE_CONFIG.name + " (fictional, demonstration)", telephone: SITE_CONFIG.phone, email: SITE_CONFIG.email,
    address: { "@type": "PostalAddress", addressLocality: "Bristol", addressCountry: "GB" }, areaServed: SITE_CONFIG.towns, openingHours: "Mo-Sa 08:00-18:00", priceRange: "££" };
  const faq = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: CONTENT.faqs.map(f => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })) };
  [local, faq].forEach(o => { const s = document.createElement("script"); s.type = "application/ld+json"; s.textContent = JSON.stringify(o); document.head.appendChild(s); });
}
