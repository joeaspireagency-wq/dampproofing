import base64, pathlib
root = pathlib.Path(__file__).parent
src = root / "src"
fonts = root / "fonts"

def face(family, path, weights):
    b64 = base64.b64encode((fonts / path).read_bytes()).decode()
    return (f"@font-face{{font-family:'{family}';font-style:normal;font-display:swap;font-weight:{weights};"
            f"src:url(data:font/woff2;base64,{b64}) format('woff2');"
            "unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}")

font_css = face("Manrope", "manrope-latin-wght-normal.woff2", "200 800") + "\n" + \
           face("Inter", "inter-latin-wght-normal.woff2", "100 900")
html = (src / "shell.html").read_text()
html = html.replace("/*__FONTS__*/", font_css).replace("/*__CSS__*/", (src / "styles.css").read_text())
parts = sorted((src / "js").glob("*.js"))
js = "(function(){\n\"use strict\";\n" + "\n".join(f.read_text() for f in parts) + "\n})();"
owner = "data:image/jpeg;base64," + base64.b64encode((src / "owner.jpg").read_bytes()).decode()
js = js.replace("__OWNER_IMG__", owner)
hero = "data:image/jpeg;base64," + base64.b64encode((src / "hero.jpg").read_bytes()).decode()
js = js.replace("__HERO_IMG__", hero)
mould = "data:image/jpeg;base64," + base64.b64encode((src / "mould.jpg").read_bytes()).decode()
js = js.replace("__MOULD_IMG__", mould)
tide = "data:image/jpeg;base64," + base64.b64encode((src / "tide.jpg").read_bytes()).decode()
js = js.replace("__TIDE_IMG__", tide)
peel = "data:image/jpeg;base64," + base64.b64encode((src / "peel.jpg").read_bytes()).decode()
js = js.replace("__PEEL_IMG__", peel)
musty = "data:image/jpeg;base64," + base64.b64encode((src / "musty.jpg").read_bytes()).decode()
js = js.replace("__MUSTY_IMG__", musty)
for _k, _f in (("__BEFORE_IMG__", "before.jpg"), ("__AFTER_IMG__", "after.jpg")):
    js = js.replace(_k, "data:image/jpeg;base64," + base64.b64encode((src / _f).read_bytes()).decode())
assert "</script" not in js.lower()
html = html.replace("/*__JS__*/", js)
out = root / "docs/index.html"
out.write_text(html)
print(out, round(len(html) / 1024), "KB")
